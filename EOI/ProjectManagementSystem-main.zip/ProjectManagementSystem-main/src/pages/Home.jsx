import NavBar from "./NavBar";
import ProjectList from "./ProjectList";

const Home = () => {
    return (
        <>
      
           <ProjectList/>
        </>
    )
}

export default Home;