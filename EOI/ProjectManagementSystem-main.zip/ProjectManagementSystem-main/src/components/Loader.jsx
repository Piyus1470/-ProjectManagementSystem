const Loader = () => {
    return (
        <>
            <p>Loading...</p>
        </>
    )
}

export default Loader;